package com.lowes.eup.exception;

public class ValidationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6889481485653405826L;

	public ValidationException(String msg) {
		super(msg);
	}

	public ValidationException(Throwable t) {
		super(t);
	}

	public ValidationException(String msg, Throwable t) {
		super(msg, t);
	}
}