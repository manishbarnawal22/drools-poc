package com.lowes.eup.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lowes.eup.facts.Product;
import com.lowes.eup.service.impl.ShopServiceImpl;

@RestController
public class ShopController {

	@Autowired
	private ShopServiceImpl shopService;

	@RequestMapping(value = "/getDiscount", method = RequestMethod.GET, produces = "application/json")
	public Product getQuestions(@RequestParam(required = true) String type) {

		Product product = new Product();
		product.setType(type);

		shopService.getProductDiscount(product);

		return product;
	}

}
