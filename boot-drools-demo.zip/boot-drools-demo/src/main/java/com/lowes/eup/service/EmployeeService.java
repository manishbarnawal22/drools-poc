package com.lowes.eup.service;

import com.lowes.eup.facts.Employee;

public interface EmployeeService {

	void storeEmployee(Employee employee);
}
