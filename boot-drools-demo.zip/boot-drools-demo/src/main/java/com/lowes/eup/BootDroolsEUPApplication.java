package com.lowes.eup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication(scanBasePackages= {"com.lowes.eup"})
public class BootDroolsEUPApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDroolsEUPApplication.class, args);
	}

}
