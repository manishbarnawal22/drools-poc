package com.lowes.eup.service.impl;

import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lowes.eup.facts.Product;
import com.lowes.eup.service.ShopService;

@Service
public class ShopServiceImpl implements ShopService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeServiceImpl.class);

	@Autowired
	private KieContainer kieContainer;

	@Override
	public Product getProductDiscount(Product product) {
		try {
			KieSession kieSession = kieContainer.newKieSession();
			kieSession.insert(product);
			kieSession.fireAllRules();
			kieSession.dispose();
		} catch (Exception e) {
			LOGGER.error("Exception occured while getting product discount:" + e.getMessage());
			throw e;
		}
		return product;
	}
}