package com.lowes.eup.service;

import com.lowes.eup.facts.Product;

public interface ShopService {

	Product getProductDiscount(Product product);
}
